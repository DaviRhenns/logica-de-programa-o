
package ex7for;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Ex7for {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n;
        double e=1, fatorial=1;
        
        System.out.println("digite um numero");
        n = teclado.nextInt();
        
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                fatorial *= j;
                
            }
            e += 10*i/fatorial;
            
            fatorial = 1;
        }
        
        System.out.println(e);
    }
    
}
