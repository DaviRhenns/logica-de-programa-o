/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex7while;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class Ex7while {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n, i=1, j=1;
        double e=1, fatorial=1;
        
        System.out.println("digite um numero");
        n = teclado.nextInt();
        
        while (i <= n) {
            while ( j <= i) {
                fatorial *= j;
                j++;
            }
            e += 10*i/fatorial;
            
            fatorial = 1;
            i++;
            j = 1;
        }
        
        System.out.println(e);
    }
    
}
