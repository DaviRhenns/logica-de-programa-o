package ex8while;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class Ex8while {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int MaiorIdade=0, MenorIdade=0, somaIdade=0, i=1, idade;
        String jogador, maisAlto, segundoAlto, terceiroAlto;
        double somaAltura=0, mediaIdade, mediaAltura, altura, altura1=0, altura2=0, altura3=0, porcentagemMais80,  mais80=0, peso;
        
        while(i <=11){
            System.out.println("digite o nome do jogador");
            jogador = teclado.nextLine();
            
            System.out.println("digite a idade do jogador");
            idade = teclado.nextInt();
            
            if (idade<18) {
                MenorIdade += 1;
            }else{
                somaIdade += idade;
            }
            
            System.out.println("digite o peso do jogador");
            peso = teclado.nextDouble();
            
            if (peso>80) {
                mais80 +=1;
            }
            
            System.out.println("digite a altura do jogador");
            altura = teclado.nextDouble();
            
            if (altura>altura1) {
                maisAlto = jogador;
            }else if (altura>altura2) {
                segundoAlto = jogador;
            } else if (altura>altura3) {
                terceiroAlto = jogador;
            }
            somaAltura += altura;
            i++;
        }
        
        mediaAltura = somaAltura/11;
        mediaIdade = somaIdade/11;
        porcentagemMais80 = (11/mais80)*100;
        
        System.out.println("jogadores menores de idade: "+ MenorIdade);
        System.out.println("media de idade dos jogadores acima de 18 anos: "+ mediaIdade);
        System.out.println("porcentagem dos jogadores com mais de 80 kg: "+ porcentagemMais80);
        System.out.println("media da altura: "+mediaAltura);
        System.out.println("jogadores mais altos: "+ maisAlto + segundoAlto + terceiroAlto);
    }
    
}
