package subrotinas1;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class SubRotinas1 {

    /**
     * @param args the command line arguments
     */
    static int mult(int a, int b){
        return a*b;
    }
    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int a, b;
        
        System.out.println("digite dois numeros");
        a = teclado.nextInt();
        b = teclado.nextInt();
        System.out.println(mult(a,b));
    }
    
}
