package li2ex18;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex18 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int cod;
        double s, ns, diferenca;
        
        System.out.println("digite o codigo do seu cargo:");
        cod = teclado.nextInt();
        
        System.out.println("digite o seu salario:");
        s = teclado.nextDouble();
        
        if (cod == 101) {
            ns = s*1.1;
        }else if (cod == 102) {
            ns = s*1.2;
        }else if (cod == 103) {
            ns = s*1.3;
        }else {
            ns = s*1.4;
        }
        
        diferenca = ns - s;
        System.out.println("antigo salario: "+s+" Novo salario: "+ns+" diferença: "+diferenca);
    }
    
}
