package li2ex16;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex16 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int cod, quant, pr;
        pr = 0;
        System.out.println("digite o codigo do produto");
        cod = teclado.nextInt();
        
        System.out.println("digite a quantidade do produto");
        quant = teclado.nextInt();
        
        if (cod == 5) {
            pr = 32*quant;
        }else if (cod == 6) {
            pr = 45*quant;
        }else if (cod == 2) {
            pr = 37*quant;
        }else if (cod == 12) {
            pr = 44*quant;
        }
        
        System.out.println("valor devido: ");
        System.out.println(pr);
    }
    
}
