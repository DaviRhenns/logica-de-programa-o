
package li2ex2;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex2 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n;
        
        System.out.println("digite o numero");
        n = teclado.nextInt();
        
        if (n%2==0) {
            System.out.println("divisivel por 2");
        }
        else {
            System.out.println("n divisivel por 2");
        }
        
        if (n%3==0) {
            System.out.println("divisivel por 3");
        }
        else {
            System.out.println("n divisivel por 3");
        }
    }
    
}
