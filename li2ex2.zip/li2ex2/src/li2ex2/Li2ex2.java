
package li2ex2;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex2 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n;
        
        System.out.println("digite o numero");
        n = teclado.nextInt();
        
        if (n%2==0 && n%3==0) {
            System.out.println("divisivel por 2 e por 3");
        }
        else{
            System.out.println("nao divisivel por ambos");
        }
    }
    
}
