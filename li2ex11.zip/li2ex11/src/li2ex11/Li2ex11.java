package li2ex11;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex11 {
    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int cod;
        double n1,n2,n3, nota;
        
        System.out.println("digite seu codigo");
        cod = teclado.nextInt();
        
        System.out.println("digite a primeira nota");
        n1 = teclado.nextDouble();
        
        System.out.println("digite a segunda nota");
        n2 = teclado.nextDouble();
        
        System.out.println("digite a terceira nota");
        n3 = teclado.nextDouble();
        
        if(n1<n2&&n1<n3){
            nota = (n1*4 + n2*3 + n3*3) / 10;
            
        }else if(n2<n1&&n2<n3){
            nota = (n2*4 + n1*3 + n3*3) / 10;
            
        }else if(n3<n2&&n3<n1){
            nota = (n3*4 + n2*3 + n1*3) / 10;
            
        }
        
        if(nota > 5){
            System.out.println("aprovado");
        }else{
            System.out.println("reprovado");
        }
        
        System.out.println(cod+", "+n1+n2+n3+" media: "+nota);
    }
    
}
