package li2ex3;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex3 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);    
        int n;
        
        System.out.println("diite o numero");
        n = teclado.nextInt();
        
        if(n%5==0 || n%7==0){
            System.out.println("divisivel por 5 ou 7");
        }
        else{
            System.out.println("nao divisivel por ambos");
        }
    }
    
}
