package li2ex25;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex25 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int golsT1, golsT2;
        String time1, time2;
        
        System.out.println("digite o nome do primeiro time");
        time1 = teclado.nextLine();
        
        System.out.println("digite os gols do primeiro time");
        golsT1 = teclado.nextInt();
        teclado.nextLine();
        
        System.out.println("digite o nome do segundo time");
        time2 = teclado.nextLine();
        
        System.out.println("digite os gols do segundo time");
        golsT2 = teclado.nextInt();
        
        if (golsT1>golsT2) {
            System.out.println(time1);
        }else if (golsT2>golsT1) {
            System.out.println(time2);
        }else{
            System.out.println("empate");
        }
    }
    
}
