package manipulacaodestring4;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class ManipulacaoDeString4 {

    /**
     * 4 – Crie um programa que apresenta o primeiro nome de um nome completo de uma pessoa que foi digitado pelo usuário;
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String nome, primeiroNome;
        
        System.out.println("digite o nome completo:");
        nome = teclado.nextLine();
        
        primeiroNome = nome.split(" ")[0];
        
        
        System.out.println(primeiroNome);
    }
    
}
