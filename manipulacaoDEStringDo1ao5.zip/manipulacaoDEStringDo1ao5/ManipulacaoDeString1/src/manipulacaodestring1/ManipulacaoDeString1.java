package manipulacaodestring1;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class ManipulacaoDeString1 {

    /**
     * 1 – Crie um programa que informa a quantidade de caracteres de uma frase informada pelo usuário;
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String frase;
        
        System.out.println("digite uma frase:");
        frase = teclado.nextLine();
        
        System.out.println("A frase tem "+frase.length()+" caracteres");
    }
    
}
