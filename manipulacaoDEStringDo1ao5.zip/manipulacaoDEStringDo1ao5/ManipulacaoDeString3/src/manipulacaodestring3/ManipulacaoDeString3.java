package manipulacaodestring3;

import java.util.Scanner;

/**
 *
 * 3 - Crie um programa que informa a quantidade de palavras de uma frase informada pelo usuário;
 */
public class ManipulacaoDeString3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String frase;
        
        System.out.println("digite uma frase:");
        frase = teclado.nextLine();
        
        System.out.println("a frase tem "+ frase.split(" ").length + " palavras");
    }
    
}
