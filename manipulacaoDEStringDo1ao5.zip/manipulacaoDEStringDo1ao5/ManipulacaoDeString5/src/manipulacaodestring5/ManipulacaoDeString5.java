package manipulacaodestring5;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class ManipulacaoDeString5 {

    /**
     *5 - Crie um programa informa o próximo ano de uma data informada no formato “dd/mm/aaaa” ou “dd/mm/aa”
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String data, ano;
        int ano2;
        
        System.out.println("digite a data:");
        data = teclado.nextLine();
        
        ano = data.split("/")[2];
        ano2 = Integer.parseInt(ano);
        
        System.out.println("o proximo ano é "+ (ano2+1));
    }
    
}
