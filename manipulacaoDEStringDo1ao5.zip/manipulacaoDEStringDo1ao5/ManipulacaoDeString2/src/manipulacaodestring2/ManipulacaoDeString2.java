package manipulacaodestring2;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class ManipulacaoDeString2 {

    /**
     * 2 - Crie um programa que informa a quantidade de vogais de uma frase informada pelo usuário;
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        String frase;
        int vogal=0;
        
        System.out.println("digite uma frase:");
        frase = teclado.nextLine();
        
        for (int i = 0; i < frase.length(); i++) {
            if (frase.toUpperCase().charAt(i) == 'A' || frase.toUpperCase().charAt(i) == 'E' || frase.toUpperCase().charAt(i) == 'I' || frase.toUpperCase().charAt(i) == 'O' || frase.toUpperCase().charAt(i) == 'U') {
                vogal++;
            }
        }
        System.out.println("A frase tem "+vogal+" vogais");
    }
    
}
