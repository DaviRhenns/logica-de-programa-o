package li2ex6;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        float n1, n2, n3;
        
        System.out.println("digite o numero 1:");
        n1 = teclado.nextFloat();
        
        System.out.println("digite o numero 2:");
        n2 = teclado.nextFloat();
        
        System.out.println("digite o numero 3:");
        n3 = teclado.nextFloat();
        
        if(n1<=n2 && n1<=n3){
            System.out.println("o menor e " + n1);
        }else if(n2<=n1 && n2<=n3){
            System.out.println("o menor e " + n2);
        }else if(n3<=n2 && n3<=n1){
            System.out.println("o menor e " + n3);
        }
    }
    
}
