package li2ex12;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String tm;
        double n1,n2,n3,m;
        
        System.out.println("selecione o tipo de media: A = aritmetica ou P = ponderada ");
        tm = teclado.nextLine();
                
        System.out.println("digite a primeira nota");
        n1 = teclado.nextDouble();
        
        System.out.println("digite a segunda nota");
        n2 = teclado.nextDouble();
        
        System.out.println("digite a terceira nota");
        n3 = teclado.nextDouble();
        
        if(tm == "A"){
            m = (n1+n2+n3)/3;
        }else{
            m = (n1*3 + n2*3 + n3*4)/10;
        }
        
        System.out.println("A média é: "+ m);
    }
    
}
