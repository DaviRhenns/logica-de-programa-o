
package li2ex1;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex1 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n;
        
        System.out.println("digite o numero");
        n = teclado.nextInt();
        
        if (n%2 == 0) {
            System.out.println("par");
        }
        else{
            System.out.println("impar");
        }
    }
    
}
