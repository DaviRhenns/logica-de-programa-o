package com.mycompany.matriz5;
import java.util.Scanner;
/**
 *
 *5) Faça um programa que preencha:
    - um vetor com nome de 4 lojas;
    - um vetor com nome de 6 produtos;
    - uma matriz com os preços de cada produto em cada loja;
    * 
    * Em seguida apresente uma listagem (Loja – produto) dos produtos acima de R$ 50,00.
 */
public class Matriz5 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int linhas = 4, colunas = 6;
        
        double precos[][] = new double[linhas][colunas];
        String produtos[] = {"Chocolate", "Refrigerante", "Kit Kat", "bolacha", "bola de Futebol", "Shampoo"};
        String lojas[] = {"Ponto Blu", "Americanas", "Angeloni", "Bistek"};
        
        for (int l = 0; l < linhas; l++) {
            for (int c = 0; c < colunas; c++) {
                System.out.println("digite o preço do produto "+produtos[c]+" na loja "+lojas[l]);
                precos[l][c] = teclado.nextDouble();
            }
        }
        
        for (int l = 0; l < linhas; l++) {
            for (int c = 0; c < colunas; c++) {
                if (precos[l][c] > 50) {
                    System.out.println("Loja: "+ lojas[l]+" Produto: "+produtos[c]+" Preço: "+ precos[l][c]);
                }
            }
        }
    }
}
