package matriz6;

import java.util.Scanner;

/**
 *
 * 6) Crie um programa que preencha uma matriz 15x5 com números inteiros. Determine e apresente quais números se repetem e quantas vezes.
 */
public class Matriz6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);    
        int linhas = 3, colunas = 3, vezesRepetidas = 0, cont=0;
        boolean repetiu = false;
        int matriz[][] = new int[linhas][colunas];
        int repetido[] = new int[linhas*colunas];
        
        System.out.println("Preencha a tabela: ");
        for (int l = 0; l < linhas; l++) {
            for (int c = 0; c < colunas; c++) {
                matriz[l][c] = teclado.nextInt();
            }
        }
        
        for (int l = 0; l < linhas; l++) {
            for (int c = 0; c < colunas; c++) {
                for (int rl = 0; rl < linhas; rl++) {
                    for (int rc = 0; rc < colunas; rc++) {
                        if (matriz[l][c] == matriz[rl][rc] && (l != rl || c != rc)) {
                            vezesRepetidas++;  
                            
                        }
                    }
                }
                
                if (vezesRepetidas!=0) {
                    for (int i = 0; i < (linhas*colunas); i++) {
                        if (repetido[i] == matriz[l][c]) {
                            repetiu = true;
                        }
                    }
                    if (repetiu == false) {
                        System.out.println("O numero "+matriz[l][c]+" repetiu "+vezesRepetidas+" vezes");
                    }
                    repetido[cont] = matriz[l][c];
                }
                vezesRepetidas=0;
                repetiu = false;
                cont++;
            }
        }
    }
    
}
