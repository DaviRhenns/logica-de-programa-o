package li2ex26;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex26 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int iH1, iH2, iM1, iM2, soma, produto, Hnovo, Hvelho, Mnova, Mvelha;
        
        System.out.println("idade homem 1:");
        iH1 = teclado.nextInt();
        
        System.out.println("idade homem 2:");
        iH2 = teclado.nextInt();
        
        System.out.println("idade mulher 1:");
        iM1 = teclado.nextInt();
        
        System.out.println("idade mulher 2:");
        iM2 = teclado.nextInt();
        
        if (iH1>iH2){
            Hnovo = iH2;
            Hvelho = iH1;
        }else{
            Hnovo = iH1;
            Hvelho = iH2;
        }
        
        if (iM1>iM2){
            Mnova = iM2;
            Mvelha = iM1;
        }else{
            Mnova = iM1;
            Mvelha = iM2;
        }
        
        soma = Hvelho + Mnova;
        produto = Hnovo * Mvelha;
        
        System.out.println("soma: "+soma);
        System.out.println("produto:"+produto);
    }
    
}
