package li1ex12;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li1ex12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n;
        
        System.out.println("digite o numero");
        n = teclado.nextInt();
        
        if (n%2 == 0) {
            System.out.println("par"); 
        }else{
            System.out.println("impar");
        }
        
        if (n>=0) {
            System.out.println("positivo");
        }else{
            System.out.println("negativo");
        }
        
    }
    
}
