
package ex5;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Ex5 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double v,c,l,a;
        
        System.out.println("digite o comprimento");
        c = teclado.nextDouble();
        
        System.out.println("digite a largura");
        l = teclado.nextDouble();
        
        System.out.println("digite a altura");
        a = teclado.nextDouble();
        
        v = c*l*a;
        System.out.println("volume: "+v);
    }
    
}
