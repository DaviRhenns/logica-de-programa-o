
package subrorina2;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class SubRorina2 {

    /**
     * Crie um programa que receba dois numeros inteiros por parametro e retorne a soma dos n numeros inteiros existentes entre eles
     */
    
    static int soma(int n1, int n2){
        int acum = 0;
        
        for (int i = n1+1; i < n2; i++) {
            acum += i;
        }
        
        return acum;
    }
    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n1, n2, numero;
        
        System.out.println("digite dois numeros:");
        n1 = teclado.nextInt();
        n2 = teclado.nextInt();
        numero = soma(n1,n2);
        System.out.println(numero);
        
    }
    
}
