package vet_3;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class Vet_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int tamanho = 9;
        boolean primo = true;
        int vetor[] = new int[tamanho];
        
        for (int i = 0; i < tamanho; i++) {
            System.out.println("digite o numero "+ (i+1)+":");
            vetor[i] = teclado.nextInt();
        }
        
        for (int i = 0; i < tamanho; i++) {
            for (int j = 2; j < vetor[i]; j++) {
                if (vetor[i]%j==0) {
                    primo = false;
                }
            }
            if (primo) {
                System.out.println(vetor[i]);
            }
            primo = true;
        }
    }
    
}
