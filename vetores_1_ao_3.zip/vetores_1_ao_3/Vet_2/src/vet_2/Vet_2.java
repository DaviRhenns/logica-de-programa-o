package vet_2;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class Vet_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int tamanho = 10, menor50=0;
        double vetor[] = new double[tamanho];
        
        for (int i = 0; i < tamanho; i++) {
            System.out.println("digite o numero "+ (i+1)+":");
            vetor[i] = teclado.nextDouble();
        }
        
        for (int i = 0; i < tamanho; i++) {
            if (vetor[i]>50) {
                System.out.println(vetor[i]);
            }else{
                menor50 += 1;
            }
        }
        if (menor50==tamanho) {
            System.out.println("nennhum numero maior que 50");
        }
    }
    
}
