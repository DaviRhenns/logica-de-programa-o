/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vet_1;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class Vet_1 {

    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int tamanho = 5;
        double vetor[] = new double[tamanho];
        
        for (int i = 0; i < tamanho; i++) {
            System.out.println("digite o numero "+ (i+1)+":");
            vetor[i] = teclado.nextDouble();
        }
        for (int i = 0; i < tamanho; i++) {
            if (vetor[i]%2==0) {
                System.out.println(vetor[i]);
            }
        }
    }
    
}
