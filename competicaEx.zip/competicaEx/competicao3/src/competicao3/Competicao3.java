/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package competicao3;

/**
 *
 * @author alunos
 */
public class Competicao3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i = 150;
        while(i<=300){
            System.out.println(i);
            i+=1;
        }
    }
    
}
