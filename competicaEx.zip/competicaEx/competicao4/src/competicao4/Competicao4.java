
package competicao4;

/**
 *
 * @author alunos
 */
public class Competicao4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i = 1000;
        while(i<=2000){
            System.out.println(i);
            i+=2;
        }
    }
    
}
