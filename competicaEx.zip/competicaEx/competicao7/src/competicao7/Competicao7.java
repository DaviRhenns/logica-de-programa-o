
package competicao7;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Competicao7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner t = new Scanner(System.in);
        int n1,n2,s=0;
        
        System.out.println("digite 2 numeros");
        n1 = t.nextInt();
        n2 = t.nextInt();
        while(n1<=n2){
            if(n1%2 != 0){
                s+=n1;
            }
            n1++;
        }
        System.out.println(s);
    }
    
}
