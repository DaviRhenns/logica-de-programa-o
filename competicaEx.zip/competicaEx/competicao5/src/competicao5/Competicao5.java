package competicao5;

/**
 *
 * @author alunos
 */
public class Competicao5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i = 100;
        
        while(i<=200){
            if(i%5 == 0 && i%3 == 0){
                System.out.println(i);
            }
            i+=1;
        }
    }
    
}
