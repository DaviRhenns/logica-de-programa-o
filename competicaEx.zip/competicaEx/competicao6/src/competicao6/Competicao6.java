package competicao6;

/**
 *
 * @author alunos
 */
public class Competicao6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int s=10;
        int a =0;
        
        while(s<=15){
            if (s%2==0 ) {
                a+=s;
            }
            s++;
        }
        System.out.println(a);
    }
    
}
