
package competicao2;

/**
 *
 * @author alunos
 */
public class Competicao2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        

    }
    
}
