package li2ex21;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex21 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int hi, hf, total;
        
        System.out.println("digite a hora inicial");
        hi = teclado.nextInt();
        
        System.out.println("digite a hora final");
        hf = teclado.nextInt();
        
        if (hi>hf) {
            total = 24-hi+hf;
        }else{
            total = hf-hi;
        }
        
        System.out.println(total+" horas jogadas");
    }
    
}
