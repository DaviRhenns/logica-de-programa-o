/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercio1;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Exercio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {


        Scanner teclado = new Scanner(System.in);
        double celsius, fahrenheit;
        
        System.out.println("digite os graus celsius");
        celsius = teclado.nextDouble();
        
        fahrenheit = (9*celsius+160)/5;
        
        System.out.println(fahrenheit+" graus fahrenheit");
    }
    
}
