package vetore.pkg4;
import java.util.Scanner;

public class Vetore4 {

    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       String frutas[] = new String [5];
       String animais[] = new String [5];
       String total[] = new String [10];
       int i = 0, real = 0;
       
        
       while(i<5){
           System.out.println("digite o nome da fruta "+(i+1));
           frutas[i] = teclado.nextLine();
           i++;
       }
        for (int j = 0; j < 5; j++) {
           System.out.println("digite o nome do animal "+(j+1));
           animais[j] = teclado.nextLine();
        }
        
        for (int j = 0; j < 10; j ++) {
            
            if (j%2==0) {
                total[j] = frutas[real];
            }else{
                total[j] = animais[real];
            }
            if (j%2!=0) {
                real++;
            }
        }
        i = 0;
        do {
            i++;
            System.out.println(total[i]);
        } while(i<9);
    }
    
}
