
package vetores.pkg6;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class Vetores6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       String veiculos[] = new String [5];
       double consumo[] = new double [5];
       double combustivel, gasto, menorE = 0, maiorE = 0;
       int real = 0;
       String menosE = "", maisE = "";
       
        System.out.println("digite o valor do combustivel");
        combustivel = teclado.nextDouble();
        teclado.nextLine();
        
        for (int i = 0; i < 5; i++) {
            System.out.println("digite o veiculo: ");
            veiculos[real] = teclado.nextLine();
            
            System.out.println("digite o consumo medio so em numeros: ");
            consumo[real] = teclado.nextDouble();
            teclado.nextLine();
            
            real++;
        }
        real=0;
        
        System.out.println("consumo dos veiculos em 780km : ");
        for (int i = 0; i < 5; i++) {
            System.out.println(veiculos[i]+" = R$"+(780/consumo[i]*combustivel));
        }
        System.out.println("");
        System.out.println("veiculo menos economico:");
        for (int i = 0; i < 5; i++) {
            if(i==0){
                menosE = veiculos[i];
                menorE = consumo[i];
            }else if (consumo[i] < menorE) {
                menosE = veiculos[i];
                menorE = consumo[i];
            }
        }
        
        System.out.println(menosE);
        System.out.println("");
        
        System.out.println("veiculo mais economico:");
        for (int i = 0; i < 5; i++) {
            if(i==0){
                maisE = veiculos[i];
                maiorE = consumo[i];
            }else if (consumo[i] > menorE) {
                maisE = veiculos[i];
                maiorE = consumo[i];
            }
        }
        System.out.println(maisE);
    }
    
}
