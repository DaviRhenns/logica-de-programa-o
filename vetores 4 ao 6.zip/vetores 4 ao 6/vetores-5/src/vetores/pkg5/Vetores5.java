
package vetores.pkg5;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class Vetores5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       int v100[] = new int [100];
       int v5[] = new int [5];
       
        for (int i = 0; i < 100; i++) {
            v100[i] = (int) (Math.random()*100);
        }
        
        int i=0;
        while(i<5){
            System.out.println("digite um numero de 0 a 100");
            v5[i] = teclado.nextInt();
            for (int j = 0; j < 100; j++) {
                if (v5[i]==v100[j]) {
                    System.out.println("seu numero esta na posição "+j);
                }
            }
            i++;
        }
    }
    
}
