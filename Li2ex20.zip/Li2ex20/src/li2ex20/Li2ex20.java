package li2ex20;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex20 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int valor, n100, n50, n10, n5, n1;
        
        System.out.println("digite o valor em reais");
        valor = teclado.nextInt();
        
        n100 = valor/100;
        valor = valor%100;
        
        n50 = valor/50;
        valor = valor%50;
        
        n10 = valor/10;
        valor = valor%10;
        
        n5 = valor/5;
        valor = valor%5;
        
        n1 = valor/1;
        valor = valor%1;
        
        System.out.println("notas de 100:"+n100);
        System.out.println("notas de 50:"+n50);
        System.out.println("notas de 10:"+n10);
        System.out.println("notas de 5:"+n5);
        System.out.println("notas de 1:"+n1);
    }
    
}
