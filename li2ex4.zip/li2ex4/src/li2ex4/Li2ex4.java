
package li2ex4;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex4 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        float n1, n2;
        
        System.out.println("digite o numero 1:");
        n1 = teclado.nextFloat();
        
        System.out.println("digite o numero 2:");
        n2 = teclado.nextFloat();
        
        if(n1>=n2){
            System.out.println(n1);
        }else{
            System.out.println(n2);
        }
    }
    
}
