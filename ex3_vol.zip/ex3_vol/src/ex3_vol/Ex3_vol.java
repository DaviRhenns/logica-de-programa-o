
package ex3_vol;
import java.util.Scanner;
/**
 *
 * @author Davi Rhenns
 */
public class Ex3_vol {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double r, a, v;        
        
        System.out.println("informe o raio da lata");
        r = teclado.nextDouble();
        
        System.out.println("informe a altura da lata");
        a = teclado.nextDouble();
        
        v = 3.14159 * r * r * a;
        
        System.out.println("volume: " + v);
    }
    
}
