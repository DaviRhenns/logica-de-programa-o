package li2ex9;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        float n1, n2;
        
        System.out.println("digite o numero 1:");
        n1 = teclado.nextFloat();
        
        System.out.println("digite o numero 2:");
        n2 = teclado.nextFloat();
        
        if(n1%n2==0 || n2%n1==0){
            System.out.println("sao multiplos");
        }else{
            System.out.println("nao sao multiplos");
        }
    }
    
}
