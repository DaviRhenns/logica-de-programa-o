package li2ex15;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double sm, c;
        
        System.out.println("digite seu saldo medio:");
        sm = teclado.nextDouble();
        
        if (sm<=200) {
            c = 0;
        }else if (sm<=400) {
            c = sm*0.2;
        }else if (sm<=600) {
            c = sm*0.3;
        }else {
            c = sm*0.40;
        }
        
        System.out.println("Saldo médio: "+sm+" Crédito: "+c);
    }
    
}
