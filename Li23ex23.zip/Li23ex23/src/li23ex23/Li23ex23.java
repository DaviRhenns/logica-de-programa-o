package li23ex23;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li23ex23 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int hi, mi, hf, mf, tempo, tempoi, tempof, tempoM,tempoH;
        
        System.out.println("digite a hora inicial");
        hi = teclado.nextInt();
        
        System.out.println("digite a minuto inicial");
        mi = teclado.nextInt();
        
        System.out.println("digite a hora final");
        hf = teclado.nextInt();
        
        System.out.println("digite a hora minuto final");
        mf = teclado.nextInt();
        
        tempoi = hi*60 + mi;
        tempof= hf*60 + mf;
        
        if (tempoi > tempof) {
           tempo = (24*60-tempoi)+tempof;
        }else{
            tempo = tempof - tempoi;
        }
        
        tempoH = tempo/60;
        tempoM = tempo%60;
        
        System.out.println(tempoH+" horas e "+tempoM+" minutos");
    }
    
}
