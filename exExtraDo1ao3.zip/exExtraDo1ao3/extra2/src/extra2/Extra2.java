package extra2;

import java.util.Scanner;

/**
 * 2e – Faça um programa onde o usuário deve digitar uma senha. Valide que essa
 * senha contenha ao menos 8 caracteres, um número, um caractere maiúsculo e um
 * símbolo. Dica: veja tabela ASCII.
 */
public class Extra2 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String senha;
        boolean minuscula = false, numero = false, simbolo = false, acertou = false;

        do {
            System.out.println("digite a senha:");
            senha = teclado.nextLine();
            
            minuscula = false;
            numero = false;
            simbolo = false;

            for (int i = 0; i < senha.length(); i++) {

                if ((int) senha.charAt(i) >= 97 && (int) senha.charAt(i) <= 122) {
                    minuscula = true;
                }
                if ((int) senha.charAt(i) >= 48 && (int) senha.charAt(i) <= 57) {
                    numero = true;
                }
                if ((int) senha.charAt(i) >= 33 && (int) senha.charAt(i) <= 47 || (int) senha.charAt(i) >= 58 && (int) senha.charAt(i) <= 64 || (int) senha.charAt(i) >= 123 && (int) senha.charAt(i) <= 125) {
                    simbolo = true;
                }

            }

            if (senha.length() >= 8 && minuscula && numero && simbolo) {
                System.out.println("senha aprovada!");
                acertou = true;
            } else {
                System.out.println("Tente novamente, a senhe deve ter pelo menos 8 characteres, pelo menos uma letra minuscula, um numero e um simbolo");
            }
        } while (!acertou);
    }

}
