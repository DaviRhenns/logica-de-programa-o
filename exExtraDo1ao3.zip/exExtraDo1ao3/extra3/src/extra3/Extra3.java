package extra3;

import java.util.Scanner;

/**
 * 3e – Faça um programa onde o usuário digita uma senha de 4 caracteres
 * alfabéticos. Utilizando um laço de repetição, e sem acessar a variável da
 * senha, descubra via força bruta qual foi a senha originalmente digitada.
 * Anote quanto tempo leva para descobrir a senha.
 */
public class Extra3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String senha;

        System.out.println("digite a senha:");
        senha = teclado.nextLine();

        for (int i = 65; i <= 122; i++) {
            if ((int) senha.charAt(0) == i) {
                
                for (int x = 65; x <= 122; x++) {
                    if ((int) senha.charAt(1) == x) {
                        
                        for (int f = 65; f <= 122; f++) {
                            if ((int) senha.charAt(2) == f) {
                                
                                for (int y = 65; y <= 122; y++) {
                                    if ((int) senha.charAt(3) == y) {
                                        System.out.println("senha digitada foi: "+ (char)i + (char)x + (char)f + (char)y);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

}
