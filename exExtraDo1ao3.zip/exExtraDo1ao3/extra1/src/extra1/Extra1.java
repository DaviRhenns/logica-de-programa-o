package extra1;
import java.util.Scanner;
/**
 * 1e – Faça um programa onde o usuário deve digitar uma senha. Essa senha deve ser previamente
    definida e estar fixa no código (contendo letras, números e símbolos). Quando o usuário acertar a
    senha, informe. Utilize um laço de repetição do-while que fica pedindo a senha repetidamente.
 */
public class Extra1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String senha = "d@v1", tentativa;
        boolean acertou = false;
        
        do{
            acertou = false;
            System.out.println("digite a senha:");
            tentativa = teclado.nextLine();
            
            if (senha.equals(tentativa)) {
                acertou = true;
            }
        }while(!acertou);
    }
    
}
