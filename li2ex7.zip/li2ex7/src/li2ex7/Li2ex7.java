package li2ex7;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex7 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        float n1, n2, n3;
        
        System.out.println("digite o numero 1:");
        n1 = teclado.nextFloat();
        
        System.out.println("digite o numero 2:");
        n2 = teclado.nextFloat();
        
        System.out.println("digite o numero 3:");
        n3 = teclado.nextFloat();
        
        if(n1<=n2 && n1<=n3){ // menor = n1
            if(n2<=n3){ 
                System.out.println(n1+", "+n2+", "+n3);
            }else{
                System.out.println(n1+", "+n3+", "+n2);
            }
            
        }else if(n2<=n1 && n2<=n3){ // menor = n2
            if(n1<=n3){
                System.out.println(n2+", "+n1+", "+n3);
            }else{
                System.out.println(n2+", "+n3+", "+n1);
            }
            
        }else if(n3<=n2 && n3<=n1){ //menor = n3
            if(n1<=n2){
                System.out.println(n3+", "+n1+", "+n2);
            }else{
                System.out.println(n3+", "+n2+", "+n1);
            }
        }
    }
    
}
