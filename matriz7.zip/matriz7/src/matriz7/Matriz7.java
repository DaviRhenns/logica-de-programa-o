package matriz7;

import java.util.Scanner;

/**
 *7) Faça um programa com vetores e matrizes, que atenda o seguinte menu descrito a
seguir. Considere como 40 alunos e 10 disciplinas a capacidade máxima do programa.
Menu:
    1 – Cadastrar um nome Disciplina (vetor)
    2 – Cadastrar um nome de Aluno (vetor)
    3 – Cadastrar uma Média de aluno em disciplina (matriz)
    4 – Listar disciplinas;
    5 – Listar alunos;
    6 – listar alunos e respectiva média em determinada disciplina;
    0 – Sair
 *
 */
public class Matriz7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);   
        int linhas = 3, colunas = 3;//Alunos = linhas  Disciplinas = colunas
        String alunos[] = new String[linhas];
        String disciplinas[] = new String[colunas];
        double notas[][] = new double[linhas][colunas];
        int escolha;
        double nota;
        String aluno, disciplina;
        
        for (int i = 0; i < colunas; i++) {
            disciplinas[i] = "";
        }
        
        System.out.println("1 – Cadastrar um nome de Disciplina");
        System.out.println("2 - Cadastrar um nome de Aluno");
        System.out.println("3 – Cadastrar uma Média de aluno em disciplina");
        System.out.println("4 – Listar disciplinas");
        System.out.println("5 – Listar alunos");
        System.out.println("6 – listar alunos e respectiva média em determinada disciplina");
        System.out.println("0 – Sair");
        
        escolha = teclado.nextInt();
        
        if (escolha==1) {
            
            for (int i = 0; i < colunas; i++) {
                if (disciplinas[i].equals("")) {
                    System.out.println("Digite o nome da disciplina:");
                    disciplinas[i] = teclado.nextLine();
                    System.out.println("Disciplina cadastrada com sucesso!");
                }
            }
            
        }else if (escolha==2) {
            
            for (int i = 0; i < linhas; i++) {
                if (alunos[i].isEmpty()) {
                    System.out.println("Digite o nome do aluno:");
                    alunos[i] = teclado.nextLine();
                    System.out.println("Aluno cadastrado com sucesso!");
                }
            }
            
        }else if (escolha==3) {
            
            System.out.println("digite o nome do aluno:");
            aluno = teclado.nextLine();
            teclado.nextLine();
            System.out.println("digite a disciplina em que deseja cadastrar a nota:");
            disciplina = teclado.nextLine();
            teclado.nextLine();
            System.out.println("Digite a nota do aluno");
            nota = teclado.nextDouble();
            
            for (int l = 0; l < linhas; l++) {
                for (int c = 0; c < colunas; c++) {
                    if (alunos[l].equals(aluno) && disciplinas[c].equals(disciplina)) {
                       notas[l][c] = nota; 
                    }
                }
            }
            
        }else if (escolha==4) {
            
            System.out.println("Disciplinas:");
            for (int c = 0; c < colunas; c++) {
                System.out.println(disciplinas[c]);
            }
            
        }
    }
    
}
