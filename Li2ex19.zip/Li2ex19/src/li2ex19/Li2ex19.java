package li2ex19;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex19 {

    /**
     * @param args the command line arguments
     */
    static double rad (double valor) {
        return Math.sqrt(valor);
    }
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int l1, l2, l3;
        double area, p;
        
        System.out.println("digite o lado 1");
        l1 = teclado.nextInt();
        
        System.out.println("digite o lado 2");
        l2 = teclado.nextInt();
        
        System.out.println("digite o lado 3");
        l3 = teclado.nextInt();
        
        if (l1+l2>l3 || l1+l3>l2 || l3+l2>l1) {
            System.out.println("Forma triangulo");
            p = (l1+l2+l3)/2.0;
            area = rad(p*(p-l1)*(p-l2)*(p-l3));
            System.out.println("area: "+area);
        }
    }
    
}
