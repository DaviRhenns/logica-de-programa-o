package subrotina4;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class SubRotina4 {

    /**
     * @param args the command line arguments
     */
    static String triangulo(int a, int b, int c){
        if(a < b+c && b < a+c && c < b+a){
            if(a==b && a==c){
                return "Equilátero";
            }else if (a==b || a==c || b==c) {
                return "Isósceles";
            }else{
                return "Escaleno";
            }
        }else{
            return "Não é triangulo";
        }
    }
    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int a,b,c;
        
        System.out.println("digite os lados do triangulo");
        a = teclado.nextInt();
        b = teclado.nextInt();
        c = teclado.nextInt();
        System.out.println(triangulo(a,b,c));
    }
    
}
