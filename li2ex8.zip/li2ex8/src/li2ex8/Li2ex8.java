package li2ex8;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex8 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        float n1, n2, n3, media;
        
        System.out.println("digite a nota 1:");
        n1 = teclado.nextFloat();
        
        System.out.println("digite a nota 2:");
        n2 = teclado.nextFloat();
        
        System.out.println("digite a nota 3:");
        n3 = teclado.nextFloat();
        
        media = (n1+n2+n3)/3;
        
        if(media >= 6){
            System.out.println("aprovado com media "+media);
        }else{
            System.out.println("reprovado com media "+media);
        }
    }
    
}
