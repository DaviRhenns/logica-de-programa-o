package exdobilk;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class ExDoBilk {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int pessoas, pessoasSuperiorMenor500=0, somaMenos25=0, somaMais25=0, pessoas2grau=0, somaIdade2grau=0, pessoasInstruidas=0, pessoasPrimario=0, somaIdadeInstruidas=0, pessosInstruidasIdadeMaior=0, pessoasMais25=0, pessoasMenos25=0;
        double mediaMais25, mediaMenos25, diferenca, mediaIdade2grau, mediaIdadeInstruidas;
        
        System.out.println("digite o numero de pessoas");
        pessoas = teclado.nextInt();
        
        double salario[] = new double[pessoas];
        int idade[] = new int[pessoas];
        int instrucao[] = new int[pessoas];
        
        for (int i = 0; i < pessoas; i++) {
            System.out.println("digite seu salario:");
            salario[i] = teclado.nextDouble();
            
            System.out.println("digite sua idade:");
            idade[i] = teclado.nextInt();
            
            System.out.println("digite seu grau de instrucao:");
            System.out.println("1 - primario");
            System.out.println("2 - 2 grau");
            System.out.println("3 - superior");
            instrucao[i] = teclado.nextInt();
            System.out.println("////////////////////////////////////////////////////////////////");
        }
        
        for (int i = 0; i < pessoas; i++) {
            if (salario[i] < 500 && instrucao[i] == 3) {
                pessoasSuperiorMenor500++;
            }
            
            if (idade[i]< 25) {
                somaMenos25 += salario[i];
                pessoasMenos25++;
            }else{
                somaMais25 += salario[i];
                pessoasMais25++;
            }
            
            if (instrucao[i] == 2) {
                pessoas2grau++;
                somaIdade2grau += idade[i];
            }
            
            if (instrucao[i] == 3) {
                pessoasInstruidas++;
                somaIdadeInstruidas+=idade[i];
            }
            
            if (instrucao[i] == 1) {
                pessoasPrimario++;
            }
            
        }
        if (pessoasInstruidas>0) {
            mediaIdadeInstruidas = (somaIdadeInstruidas*1.0)/(pessoasInstruidas*1.0);
        }else{
            mediaIdadeInstruidas = 0;
        }
        
        
        for (int i = 0; i < pessoas; i++) {
            if (idade[i]>mediaIdadeInstruidas) {
                pessosInstruidasIdadeMaior++;
            }
        }
        
        if (pessoasMais25>0) {
            mediaMais25 = (somaMais25*1.0)/(pessoasMais25*1.0);
        }else{
            mediaMais25 = 0;
        }
        
        if (pessoasMenos25>0) {
            mediaMenos25 = (somaMenos25*1.0)/(pessoasMenos25*1.0);
        }else{
            mediaMenos25 = 0;
        }
        
        diferenca = mediaMais25 - mediaMenos25;
        
        if (pessoas2grau>0) {
            mediaIdade2grau = (somaIdade2grau*1.0)/(pessoas2grau/1.0);
        }else{
            mediaIdade2grau = 0;
        }
        
        System.out.println("numero de pessoas com ensino superior que ganham menos de R$500,00: " + pessoasSuperiorMenor500);
        System.out.println("diferenca entre o salario de pessoas com 25 ou mais e pessoas com menos de 25: " + diferenca);
        System.out.println("media da idade das pessoas com 2 grau: " + mediaIdade2grau);
        System.out.println("percentual de pessoas com o curso superior: "+ ((pessoasInstruidas*1.0)/(pessoas*1.0)*100));
        System.out.println("percentual de pessoas com apenas o curso primario: "+ ((pessoasPrimario*1.0)/(pessoas*1.0)*100));
        System.out.println("media da idade das pessoas instruidas: " + mediaIdadeInstruidas);
        System.out.println("pessoas instruidas com idades acima da media: " + pessosInstruidasIdadeMaior);
    }
    
}
