/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex2_f_c;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Ex2_F_C {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double celsius, fahrenheit;
        
        System.out.println("digite os graus fahrenheit");
        fahrenheit = teclado.nextDouble();
        
        celsius = (fahrenheit-32)/1.8;
        
        System.out.println(celsius + "graus celsius");
    }
    
}
