/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package subrotina2.pkg1;

/**
 *
 * @author alunos
 */
public class SubRotina21 {

    /**
     * Um programa que use recursividade para apresentar os números de ZERO
a 100 na tela. Portanto, não utilize laços de repetição.
     */
    static void zeroacem(int numero){
        System.out.println(numero);
         if (numero < 100) {
            zeroacem(numero+1);
        }
    }
    
    public static void main(String[] args) {
        zeroacem(0);
    }
    
}
