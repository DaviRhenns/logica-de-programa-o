
package subrotina7;
/**
 *
 *Cie uma sub-rotina que recebe um
número por parâmetro e retorna true
caso seja um número primo, e false
caso contrário. O programa principal
deve permitir testar a sub-rotina e
apresentar o texto “Primo” ou “Não
primo” coerentemente.
 */
public class SubRotina7 {

    /**
     * @param args the command line arguments
     */
    static String primo(int n){
        boolean primo = true;
        
        for (int i = 2; i < n; i++) {
            if (n % i == 0) {
                primo = false;
            }
        }
         if (primo && n != 2) {
            return "é primo";
        }else{
            return "não é primo";
         }
    }
    
    public static void main(String[] args) {
        
        System.out.println(primo(23));
    }
    
}
