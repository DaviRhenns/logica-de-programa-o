package subrotina5;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class SubRotina5 {

    /**
     * 5. Crie uma sub-rotina que receba 3 notas de um alno como parâmetros e uma letra.
Se a letra for A, a sub-rotina deverá calcular e retornar a média aritmética das notas do aluno; 
* se for P, deverá calcular e retornar a média ponderada, como pesos, 5, 3 e 2. 
A média calculada deve ser devolvida ao programa principal e então exibida.
     */
    
    static double media(double n1, double n2, double n3, char tipo){
        if (tipo == 'A' || tipo == 'a') {
            return (0.0 + n1 + n2 + n3)/3.0;
        }else{
            return(n1*5.0 + n2*3.0 + n3*2.0)/10.0 ;
        }
    }
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double n1, n2, n3;
        char tipo;
        System.out.println("digite as 3 notas do aluno");
        n1 = teclado.nextDouble();
        n2 = teclado.nextDouble();
        n3 = teclado.nextDouble();
        
        System.out.println("digite P para media ponderada e A para media arimetrica");
        tipo = teclado.next().charAt(0);
        
        System.out.println("a media é:"+media(n1,n2,n3,tipo));
    }
    
}
