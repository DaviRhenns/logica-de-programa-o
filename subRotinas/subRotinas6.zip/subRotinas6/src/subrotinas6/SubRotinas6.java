
package subrotinas6;

import java.util.Scanner;

/**
 * 6. Crie uma sub-rotina que receba como parâmetro o início e o término de um jogo, ambos subdivididas em dois valores inteiros
distintos: horas e minutos (portanto, serão 4 parâmetros). A sub-rotina deverá retornar a duração expressa em minutos, considerando
que a duração máxima é de 24 horas e que um jogo pode iniciar em um dia e terminar em outro.
 */
public class SubRotinas6 {

    static int minutos(int hi, int mi, int hf, int mf){
        int minutosI = hi*60 + mi;
        int minutosF = hf*60 + mf;   
        
        if (minutosI < minutosF) {
            return minutosF - minutosI;
        }else{
            return 1440 - minutosI + minutosF;
        }
    }
    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int hi, hf, mi, mf;
        System.out.println("digite a hora de inicio do jogo");
        hi = teclado.nextInt();
        
        System.out.println("digite o minuto de inicio do jogo");
        mi = teclado.nextInt();
        
        System.out.println("digite a hora de fim do jogo");
        hf = teclado.nextInt();
        
        System.out.println("digite o minuto de fim do jogo");
        mf = teclado.nextInt();
        
        System.out.println(minutos(hi,mi,hf,mf)+" minutos");
    }
    
}
