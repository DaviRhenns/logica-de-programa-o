package subrotina2.pkg3;

/**
 *
 * @author alunos
 */
public class SubRotina23 {

    /**
     * Um programa com uma subrotina que recebe um vetor de números por parâmetro e retorna o maior número.
     */
    static int maior (int vetor[], int i, int maiorN){
        
        if (i >= vetor.length) {
            return maiorN;
        }
        
        if (maiorN < vetor[i]) {
            maiorN = vetor[i];
        }
        
        
        
        return maior(vetor, i+1, maiorN);
    }
    
    public static void main(String[] args) {
        int vetor[] = {9,7,3,4};
        int i = 0, maiorN = vetor[0];
        System.out.println(maior(vetor, i, maiorN));
    }
    
}
