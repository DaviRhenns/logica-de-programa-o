/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package subrotina2.pkg2;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Subrotina22 {

    /**
    Um programa que use recursividade para determinar se uma palavra é um palíndromo. Portanto, não utilize laços de repetição.
    EX:
        arara = é um palíndromo
        casa = Não é palíndromo
        Ana = é um palíndromo
        verde = Não é palíndromo
        sopapos = é um palíndromo
     */
    
    static boolean ehPalindromo(String palavra, int chari, int charf){
        if (charf<=chari) {
            return true;
        }
        if (palavra.charAt(chari) != palavra.charAt(charf)) {
            return false;
        }
        return ehPalindromo(palavra, chari+1, charf-1);
    }
    
    public static void main(String[] args) {
        Scanner teclado =  new Scanner (System.in);
        String palavra;
        
        System.out.println("digite a palavra");
        palavra = teclado.nextLine();
        
        if(ehPalindromo(palavra, 0, palavra.length()-1)){
            System.out.println("A palavra e palindromo");
        }else{
            System.out.println("Nao e palindromo");
        }
    }
    
}
