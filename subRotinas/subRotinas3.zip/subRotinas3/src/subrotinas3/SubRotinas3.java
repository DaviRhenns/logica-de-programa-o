package subrotinas3;
import java.util.Scanner;
/**
 *
 * 3. Crie um programa com uma sub-rotina que receba um único valor representando segundos. Essa deverá convertê-lo em horas, minutos e segundos e apresentar o resultado na
tela. O programa principal deve permitir testar a mesma.
 */
public class SubRotinas3 {

    /**
     * @param args the command line arguments
     */
    static String converter(int s)
    {
        String resp;
        int m,h;
        
        h = s/3600;
        m = s/60%60;
        
        
        if(s > 60){
            s = s%60%60;
        }
        
        resp = h+":"+m+":"+s;
        return resp;
        
    }    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int secs;
        
        System.out.println("digite o numero de segundos");
        secs = teclado.nextInt();
        
        System.out.println(converter(secs));
        
    }
    
}
