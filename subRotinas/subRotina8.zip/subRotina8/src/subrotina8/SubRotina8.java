package subrotina8;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class SubRotina8 {

    /**
     * Crie uma sub-rotina que receba 5 valores inteiros, determine e mostre o maior e o menor deles.
O programa principal deve indagar

esses números ao usuário.
     */
    static void maiorMenor(int numeros[]){
        int maior = numeros[0], menor = numeros[0];
        
        for (int i = 0; i < 5; i++) {
            if (numeros[i] >= maior) {
                maior = numeros[i];
            }
            
        }
        
        for (int i = 0; i < 5; i++) {
            if (numeros[i] <= menor) {
                menor = numeros[i];
            }
        }
        
        System.out.println("maior: " + maior);
        System.out.println("menor: "+ menor);
    }
    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int numeros[] = new int[5];
        
        System.out.println("digite os 5 numeros");
        
        for (int i = 0; i < 5; i++) {
            numeros[i] = teclado.nextInt();
        }
        maiorMenor(numeros);
    }
    
}
