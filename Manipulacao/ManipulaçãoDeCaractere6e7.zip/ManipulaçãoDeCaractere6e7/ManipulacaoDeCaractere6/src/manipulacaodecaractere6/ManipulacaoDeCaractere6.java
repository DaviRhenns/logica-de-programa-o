package manipulacaodecaractere6;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class ManipulacaoDeCaractere6 {

    /**
     * 6 – Crie um programa onde o usuário informa o nome completo de uma pessoa. Monte
em uma nova variável e apresente o sobre-nome seguido de vírgula e os demais nomes.
Exemplo: Paulo Eduardo Marcondes Silva → Silva, Paulo Eduardo Marcondes
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String nomeCompleto, nomeCorreto="";
        
        
        System.out.println("digite seu nome completo:");
        nomeCompleto = teclado.nextLine();
        
        String nomeSplit[] = nomeCompleto.split(" ");
        
        String ultimoNome = nomeSplit[nomeSplit.length-1];
        
        nomeCorreto += ultimoNome +", ";
        
        for (int i = 0; i < nomeSplit.length-1; i++) {
            nomeCorreto += nomeSplit[i]+" ";
        }
        System.out.println("Nome Correto: "+ nomeCorreto);
    }
    
}
