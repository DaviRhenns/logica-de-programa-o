package manipulacaodecaractere7;

import java.util.Scanner;

/**
 *
 * @author alunos
 */
public class ManipulacaoDeCaractere7 {

    /**
     * 7 – Crie um programa onde o usuário informa o nome completo de uma pessoa. Monte
em uma nova variável e apresenta esse nome com os nomes do meio abreviados.
Ex. Paulo Eduardo Marcondes Silva → Paulo E. M. Silva
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String nome, nomeCorreto="";
        
        System.out.println("digite seu nome completo:");
        nome = teclado.nextLine();
        
        String nomeSplit[] = nome.split(" ");
        
        nomeCorreto += nomeSplit[0] + " ";
        
        for (int i = 1; i < nomeSplit.length-1; i++) {
            nomeCorreto += nomeSplit[i].charAt(0) + ". ";
        }
        nomeCorreto += nomeSplit[nomeSplit.length-1];
        
        System.out.println("nome correto: "+nomeCorreto);
    }
    
}
