package li2ex27;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex27 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int aluno;
        double n1, n2, n3, me, ma;
        
        System.out.println("digite o codigo do aluno");
        aluno = teclado.nextInt();
        
        System.out.println("digite a primeira nota do aluno");
        n1 = teclado.nextDouble();
        
        System.out.println("digite a segunda nota do aluno");
        n2 = teclado.nextDouble();
        
        System.out.println("digite a terceira nota do aluno");
        n3 = teclado.nextDouble();
        
        me = (n1+n2+n3)/3.0;
        ma = (n1+n2*2+n3*3+me)/7.0;
        
        System.out.println("Aluno: "+aluno);
        System.out.println("nota 1: "+n1+" nota 2: "+n2+" nota 3: "+n3);
        System.out.println("Media: "+me);
        System.out.println("Media de aproveitamento: "+ma);
        
        if (ma>=9) {
            System.out.println("conceito: A");
            System.out.println("Aprovado");
        }else if (ma>=7.5) {
            System.out.println("conceito: B");
            System.out.println("Aprovado");
        }else if (ma>=6) {
            System.out.println("conceito: C");
            System.out.println("Aprovado");
        }else if (ma>=4) {
            System.out.println("conceito: D");
            System.out.println("Reprovado");
        }else {
            System.out.println("conceito: E");
            System.out.println("Reprovado");
        }
    }
    
}
