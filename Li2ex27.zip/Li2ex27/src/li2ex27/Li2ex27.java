package li2ex27;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex27 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
    }
    
}
