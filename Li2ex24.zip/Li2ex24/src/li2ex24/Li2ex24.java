package li2ex24;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex24 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int nM;
        double preco;
        
        System.out.println("digite o numero de maçãs");
        nM = teclado.nextInt();
        
        if (nM<12) {
            preco = nM*1.3;
        }else{
            preco = nM;
        }
        
        System.out.println("a compra deu "+preco+" reais");
    }
    
}
