
package li3ex1;

/**
 *
 * @author alunos
 */
public class Li3ex1 {

    
    public static void main(String[] args) {
        int tabuada = 0, resultado, multiplicador = 0;
        ///////////////////////////////////////////////////////////////////////////////////////////////
        System.out.println("Com while");
        System.out.println("");
        System.out.println("");
        
        while(tabuada != 11){
            while(multiplicador != 11){
                resultado = tabuada*multiplicador;
                
                System.out.println(tabuada+" X "+multiplicador+" = "+resultado);
                
                multiplicador++;
                
            }    
            multiplicador = 0;
            tabuada++;
            System.out.println("");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////
        System.out.println("");
        System.out.println("Com for");
        System.out.println("");
        System.out.println("");
        
        for (tabuada = 0; tabuada != 11; tabuada++) {
            for (multiplicador = 0; multiplicador != 10; multiplicador++) {
                resultado = tabuada*multiplicador;
                System.out.println(tabuada+" X "+multiplicador+" = "+resultado);
            }
            System.out.println("");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////
        System.out.println("");
        System.out.println("Com do-while");
        System.out.println("");
        System.out.println("");
     
        multiplicador = 0;
        tabuada = 0;
        do{
            do{
                resultado = tabuada*multiplicador;
                
                System.out.println(tabuada+" X "+multiplicador+" = "+resultado);
                
                multiplicador++;
                
            }while(multiplicador != 11);    
            multiplicador = 0;
            tabuada++;
            System.out.println("");
        }while(tabuada != 11);
    }
    
}
