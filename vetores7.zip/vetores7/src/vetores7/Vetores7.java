package vetores7;
import java.util.Scanner;
public class Vetores7 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String funcionarios[] = new String[5];
        double salarios[] = new double[5];
        int tempo[] = new int[5];
        double novoS;
        
        for (int i = 0; i < 5; i++) {
            System.out.println("digite o nome do funcionario");
            funcionarios[i] = teclado.nextLine();
            
            System.out.println("digite o salario do funcionario");
            salarios[i] = teclado.nextDouble();
            
            System.out.println("digite o tempo de servico do funcionario");
            tempo[i] = teclado.nextInt();
            teclado.nextLine();
        }
        
        System.out.println("funcionarios sem aumento:");
        for (int i = 0; i < 5; i++) {
            if (tempo[i]<=5 && salarios[i]>1940) {
                System.out.println(funcionarios[i]);
            }
        }
        
        System.out.println("funcionarios com aumento e novos salarios");
        for (int i = 0; i < 5; i++) {
            if (tempo[i]>5) {
                if (salarios[i]<1940) {
                    novoS = salarios[i]*1.35;
                    System.out.println(funcionarios[i]+" = "+novoS);
                }else{
                    novoS = salarios[i]*1.25;
                    System.out.println(funcionarios[i]+" = "+novoS);
                }
            }else if (salarios[i]<1940) {
                novoS = salarios[i]*1.15;
                System.out.println(funcionarios[i]+" = "+novoS);
            } 
        }
    }
    
}
