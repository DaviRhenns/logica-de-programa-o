package li2ex22;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int i;
        double a,b,c;
        
        System.out.println("digite o valor de i");
        i = teclado.nextInt();
        
        System.out.println("digite o valor de a");
        a = teclado.nextDouble();
        
        System.out.println("digite o valor de b");
        b = teclado.nextDouble();
        
        System.out.println("digite o valor de c");
        c = teclado.nextDouble();
        
        if (i==1) {
            if (a>=b && a>=c) {
                if (b>=c) {
                    System.out.println(c+", "+b+", "+a);
                }else{
                    System.out.println(b+", "+c+", "+a);
                }
            }else if (b>=a && b>=c) {
                if (a>=c) {
                    System.out.println(c+", "+a+", "+b);
                }else{
                    System.out.println(a+", "+c+", "+b);
                }
            }else{
                if (a>=b) {
                    System.out.println(b+", "+a+", "+c);
                }else{
                    System.out.println(a+", "+b+", "+c);
                }
            } 
        }else if (i==2) {
            if (a>=b && a>=c) {
                if (b>=c) {
                    System.out.println(a+", "+b+", "+c);
                }else{
                    System.out.println(a+", "+c+", "+b);
                }
            }else if (b>=a && b>=c) {
                if (a>=c) {
                    System.out.println(b+", "+a+", "+c);
                }else{
                    System.out.println(b+", "+c+", "+a);
                }
            }else{
                if (a>=b) {
                    System.out.println(c+", "+a+", "+b);
                }else{
                    System.out.println(c+", "+b+", "+a);
                }
            }
        }else if(i==3){
            if (a>=b && a>=c) {
                System.out.println(b+", "+a+", "+c);
            }else if (b>=a && b>=c) {
                System.out.println(a+", "+b+", "+c);
            }else{
                System.out.println(b+", "+c+", "+a);
            }
        }
    }
    
}
