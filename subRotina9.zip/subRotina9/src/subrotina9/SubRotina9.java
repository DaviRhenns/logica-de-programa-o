package subrotina9;

import java.util.Scanner;

/**
 *
 * 9- Criem uma sub-rotina que recebe por parâmetro
o nome completo de uma pessoa e retorna esse
nome com os nomes do meio abreviados.
 */
public class SubRotina9 {

    static String converterNome(String nome){
        String nomeCortado[] = nome.split(" ");
        String nomeCorreto = nomeCortado[0];
        
        for (int i = 1; i < nomeCortado.length - 1; i++) {
            nomeCorreto += " " + nomeCortado[i].charAt(0) + ".";
        }
        nomeCorreto += " " + nomeCortado[nomeCortado.length-1];
        
        return nomeCorreto;
    }
    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String nome;
        
        System.out.println("digite o nome:");
        nome = teclado.nextLine();
        
        System.out.println(converterNome(nome));
    }
    
}
