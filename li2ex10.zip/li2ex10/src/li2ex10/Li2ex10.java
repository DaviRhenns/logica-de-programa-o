package li2ex10;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Li2ex10 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int idade;
        String nome;
        
        System.out.println("digite o nome do atleta");
        nome = teclado.nextLine();
        
        System.out.println("digite a idade do atleta");
        idade = teclado.nextInt();
        
        System.out.println("Nome: "+ nome);
        
        if(idade>=5){
            if(idade<=7){
                System.out.println("infantil A");
            }else if(idade<=10){
                System.out.println("infantil B");
            }else if(idade<=13){
                System.out.println("juvenil A");
            } else if(idade<=17){
                System.out.println("juvenil B");
            }else{
                System.out.println("adulto");
            }
        }else{
            System.out.println("sem categoria");
        }
        
    }
    
}
