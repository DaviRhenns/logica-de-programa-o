
package ex4;
import java.util.Scanner;
/**
 *
 * @author alunos
 */
public class Ex4_troca {

  
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n1,n2,n3;

        System.out.println("digite o numero 1:");
        n1 = teclado.nextInt();
       
        System.out.println("digite o numero 2:");
        n2 = teclado.nextInt();
        
        n3 = n1;
        n1 = n2;
        n2 = n3;
        
        System.out.println("n1 e n2: " + n1 + " " + n2);
        
    }
    
}
